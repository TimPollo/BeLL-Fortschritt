# BeLL Fortschritt

Kleine installierbare Web-App (PWA) zum Abhaken der Kapitel der Besonderen Lernleistung.

## Dateien, die ins GitHub-Repository müssen

- `index.html`
- `manifest.webmanifest`
- `sw.js`
- `icon-192.png`
- `icon-512.png`
- `icon-512-maskable.png`
- `apple-touch-icon.png`
- `favicon-32.png`

`logo-source.png` ist nur die hochauflösende Ausgangsdatei des Logos und für die App nicht zwingend nötig.

## GitHub Pages aktivieren

1. Alle oben genannten Dateien in die oberste Ebene des Repositories hochladen.
2. GitHub öffnen: **Settings → Pages**.
3. Unter **Build and deployment**: **Deploy from a branch** wählen.
4. Branch **main** und Ordner **/(root)** auswählen und speichern.
5. Die von GitHub angezeigte Pages-Adresse öffnen.

## Auf iPhone/iPad als App installieren

1. Die GitHub-Pages-Adresse in Safari öffnen.
2. **Teilen** antippen.
3. **Zum Home-Bildschirm** wählen.
4. Als Name z. B. `BeLL` verwenden und hinzufügen.

Die Häkchen werden im lokalen Browser-Speicher des jeweiligen Geräts gespeichert.
